const PANEL_ID = "xh-erp-panel";
const PLID_REGEX = /PLID(\d+)/i;

const state = {
  plid: null,
  title: "",
  settings: null,
  preview: null,
  loading: false,
  pricingDraft: {
    airFreightUnitCnyPerKg: "",
    purchasePriceCny: "",
    salePriceZar: "",
    actualWeightKg: "",
    lengthCm: "",
    widthCm: "",
    heightCm: "",
  },
};

function findOwnTextElement(pattern) {
  const elements = Array.from(document.querySelectorAll("h2,h3,h4,strong,span,p,div"));
  return elements.find((element) => {
    if (!(element instanceof HTMLElement) || element.closest(`#${PANEL_ID}`)) {
      return false;
    }
    const text = (element.textContent || "").trim();
    return text.length > 0 && text.length < 120 && pattern.test(text);
  });
}

function getNearestCardLikeBlock(element) {
  let current = element;
  let best = element;
  for (let depth = 0; current && depth < 7; depth += 1) {
    const rect = current.getBoundingClientRect();
    if (rect.width >= 220 && rect.height >= 40) {
      best = current;
    }
    if (rect.width >= 260 && rect.height >= 86) {
      break;
    }
    current = current.parentElement;
  }
  return best;
}

function getSidebarMountReference() {
  const creditNode = findOwnTextElement(/takealot\.credit|eBucks|Discovery\s*MILES/i);
  if (creditNode) {
    return getNearestCardLikeBlock(creditNode);
  }

  const otherOffersNode = findOwnTextElement(/^Other Offers$/i);
  if (otherOffersNode) {
    return otherOffersNode;
  }

  const soldByNode = findOwnTextElement(/^Sold by/i);
  if (soldByNode) {
    return getNearestCardLikeBlock(soldByNode).nextElementSibling;
  }

  return null;
}

function mountPanel(panel) {
  const reference = getSidebarMountReference();
  if (reference?.parentElement) {
    panel.dataset.placement = "sidebar";
    if (panel.parentElement !== reference.parentElement || panel.nextElementSibling !== reference) {
      reference.parentElement.insertBefore(panel, reference);
    }
    return;
  }

  panel.dataset.placement = "floating";
  if (panel.parentElement !== document.body) {
    document.body.appendChild(panel);
  }
}

function extractPlid() {
  const match = window.location.href.match(PLID_REGEX);
  return match ? match[1] : null;
}

function getProductTitle() {
  const titleNode =
    document.querySelector("h1") ||
    document.querySelector('[data-testid="product-title"]') ||
    document.querySelector("title");
  return titleNode ? (titleNode.textContent || "").trim() : "";
}

function getPanel() {
  let panel = document.getElementById(PANEL_ID);
  if (!panel) {
    panel = document.createElement("section");
    panel.id = PANEL_ID;
  }
  mountPanel(panel);
  return panel;
}

function setLoading(loading) {
  state.loading = loading;
  const panel = getPanel();
  panel.dataset.loading = loading ? "true" : "false";
}

function buildDisconnectedView() {
  const baseUrl = state.settings?.erpBaseUrl || "";
  return `
    <div class="xh-panel-header">
      <div>
        <div class="xh-kicker">Xiaohei ERP</div>
        <div class="xh-title">连接 ERP</div>
      </div>
      <button class="xh-refresh" type="button" data-action="refresh">↻</button>
    </div>
    <div class="xh-block xh-block-compact">
      <div class="xh-subtitle">先连接，再自动显示商品护栏与上架入口</div>
      <div class="xh-field">
        <label class="xh-field-label">ERP 地址</label>
        <input class="xh-input" data-field="erp-base-url" placeholder="例如 https://erp.example.com" value="${escapeHtml(baseUrl)}" />
      </div>
      <div class="xh-field">
        <label class="xh-field-label">账号</label>
        <input class="xh-input" data-field="erp-username" placeholder="输入 ERP 账号" />
      </div>
      <div class="xh-field">
        <label class="xh-field-label">密码</label>
        <input class="xh-input" data-field="erp-password" type="password" placeholder="输入 ERP 密码" />
      </div>
      <button class="xh-primary xh-full" data-action="login" type="button">登录 ERP</button>
      <div class="xh-hint" data-field="global-hint">登录成功后，扩展会自动保存连接。</div>
    </div>
  `;
}

function buildConnectedView() {
  const user = state.settings?.extensionUser;
  const stores = Array.isArray(state.settings?.extensionStores) ? state.settings.extensionStores : [];
  const selectedStoreId = state.settings?.defaultStoreId || "";
  const storeOptions = stores.map((store) => {
    const selected = store.store_id === selectedStoreId ? "selected" : "";
    return `<option value="${escapeHtml(store.store_id)}" ${selected}>${escapeHtml(store.name)}</option>`;
  }).join("");

  const guardrailStatus =
    state.preview?.guardrail?.status ||
    state.preview?.product?.fact_status ||
    "waiting";
  const weight = state.preview?.product?.merchant_packaged_weight_raw || "未补全";
  const dimensions = state.preview?.product?.merchant_packaged_dimensions_raw || "未补全";
  const protectedFloor = state.preview?.guardrail?.protected_floor_price || "";
  const pricing = state.preview?.pricing || null;
  const draftAirFreight = state.pricingDraft.airFreightUnitCnyPerKg || (pricing?.air_freight_unit_cny_per_kg != null ? String(pricing.air_freight_unit_cny_per_kg) : "79");
  const draftPurchasePrice = state.pricingDraft.purchasePriceCny || "";
  const draftSalePrice = state.pricingDraft.salePriceZar || (pricing?.sale_price_zar != null ? String(pricing.sale_price_zar) : "");
  const draftActualWeight = state.pricingDraft.actualWeightKg || (state.preview?.product?.actual_weight_kg != null ? String(state.preview.product.actual_weight_kg) : "");
  const draftLength = state.pricingDraft.lengthCm || (state.preview?.product?.length_cm != null ? String(state.preview.product.length_cm) : "");
  const draftWidth = state.pricingDraft.widthCm || (state.preview?.product?.width_cm != null ? String(state.preview.product.width_cm) : "");
  const draftHeight = state.pricingDraft.heightCm || (state.preview?.product?.height_cm != null ? String(state.preview.product.height_cm) : "");
  const recommendedPrice10 = pricing?.recommended_price_10_zar ?? "待测算";
  const recommendedPrice30 = pricing?.recommended_price_30_zar ?? "待测算";
  const suggestedProtectedFloor = pricing?.recommended_protected_floor_price_zar ?? "待测算";
  const estimatedProfit = pricing?.profit_zar ?? "待测算";
  const estimatedMargin = pricing?.margin_rate != null
    ? `${(Number(pricing.margin_rate) * 100).toFixed(2)}%`
    : "待测算";
  const breakEvenPrice = pricing?.break_even_price_zar ?? "待测算";
  const chargeableWeight = pricing?.chargeable_weight_kg ?? "待测算";
  const displayChargeableWeight = typeof chargeableWeight === "number" ? `${formatNumber(chargeableWeight, 2)} kg` : chargeableWeight;
  const displayProfit = typeof estimatedProfit === "number" ? formatZar(estimatedProfit) : estimatedProfit;
  const displayRecommendedPrice10 = typeof recommendedPrice10 === "number" ? formatZar(recommendedPrice10) : recommendedPrice10;
  const displayRecommendedPrice30 = typeof recommendedPrice30 === "number" ? formatZar(recommendedPrice30) : recommendedPrice30;
  const displaySuggestedProtectedFloor =
    typeof suggestedProtectedFloor === "number" ? formatZar(suggestedProtectedFloor) : suggestedProtectedFloor;
  const modalProtectedFloor =
    protectedFloor ||
    (pricing?.recommended_protected_floor_price_zar != null
      ? String(pricing.recommended_protected_floor_price_zar)
      : "");

  return `
    <div class="xh-panel-header">
      <div>
        <div class="xh-kicker">Xiaohei ERP</div>
        <div class="xh-title">上架试算</div>
      </div>
      <div class="xh-header-actions">
        <button class="xh-refresh" type="button" data-action="refresh" title="刷新">↻</button>
        <button class="xh-ghost" type="button" data-action="logout">退出</button>
      </div>
    </div>

    <div class="xh-dimensions">${escapeHtml(weight)} · ${escapeHtml(dimensions)}</div>

    <div class="xh-block">
      <div class="xh-grid">
        <div class="xh-field">
          <label class="xh-field-label">空运单价 (CNY/kg)</label>
          <input class="xh-input" data-field="air-freight-unit" inputmode="decimal" placeholder="79" value="${escapeHtml(draftAirFreight)}" />
        </div>
        <div class="xh-field">
          <label class="xh-field-label">采购价 (CNY)</label>
          <input class="xh-input" data-field="purchase-price" inputmode="decimal" placeholder="0" value="${escapeHtml(draftPurchasePrice)}" />
        </div>
        <div class="xh-field">
          <label class="xh-field-label">销售价 (ZAR)</label>
          <input class="xh-input" data-field="sale-price" inputmode="decimal" placeholder="0" value="${escapeHtml(draftSalePrice)}" />
        </div>
        <div class="xh-field">
          <label class="xh-field-label">重量 (kg)</label>
          <input class="xh-input" data-field="actual-weight" inputmode="decimal" placeholder="0" value="${escapeHtml(draftActualWeight)}" />
        </div>
        <div class="xh-field">
          <label class="xh-field-label">长 (cm)</label>
          <input class="xh-input" data-field="length-cm" inputmode="decimal" placeholder="0" value="${escapeHtml(draftLength)}" />
        </div>
        <div class="xh-field">
          <label class="xh-field-label">宽 (cm)</label>
          <input class="xh-input" data-field="width-cm" inputmode="decimal" placeholder="0" value="${escapeHtml(draftWidth)}" />
        </div>
        <div class="xh-field">
          <label class="xh-field-label">高 (cm)</label>
          <input class="xh-input" data-field="height-cm" inputmode="decimal" placeholder="0" value="${escapeHtml(draftHeight)}" />
        </div>
      </div>
      <button class="xh-secondary xh-full" data-action="recalculate" type="button">重新试算</button>
    </div>

    <div class="xh-block">
      <div class="xh-subtitle">结果</div>
      <div class="xh-result-grid">
        <div class="xh-stat"><span>计费重</span><strong>${escapeHtml(String(displayChargeableWeight))}</strong></div>
        <div class="xh-stat"><span>利润</span><strong>${escapeHtml(String(displayProfit))}</strong></div>
        <div class="xh-stat"><span>利润率</span><strong>${escapeHtml(String(estimatedMargin))}</strong></div>
        <div class="xh-stat"><span>10% 利润售价</span><strong>${escapeHtml(String(displayRecommendedPrice10))}</strong></div>
        <div class="xh-stat"><span>30% 利润售价</span><strong>${escapeHtml(String(displayRecommendedPrice30))}</strong></div>
        <div class="xh-stat"><span>建议保护价</span><strong>${escapeHtml(String(displaySuggestedProtectedFloor))}</strong></div>
      </div>
      <div class="xh-hint" data-field="global-hint">${escapeHtml(pricing?.note || "输入试算参数后显示推荐售价。")}</div>
    </div>

    <div class="xh-block xh-block-compact">
      <button class="xh-primary xh-full" data-action="open-list-now" type="button">一键上架</button>
    </div>

    <div class="xh-modal hidden" data-modal="list-now">
      <div class="xh-modal-card">
        <div class="xh-modal-header">
          <div>
            <div class="xh-title-sm">一键上架</div>
            <div class="xh-modal-subtitle">${escapeHtml(user?.username || "已连接")} · ${escapeHtml(state.plid || "-")}</div>
          </div>
          <button class="xh-ghost" type="button" data-action="close-list-now">关闭</button>
        </div>
        <div class="xh-field">
          <label class="xh-field-label">上架店铺</label>
          <select class="xh-select" data-field="modal-store-select">
            ${storeOptions}
          </select>
        </div>
        <div class="xh-field">
          <label class="xh-field-label">保护价 (ZAR)</label>
          <div class="xh-input-row">
            <input class="xh-input" data-field="modal-protected-floor" inputmode="decimal" placeholder="输入保护价" value="${escapeHtml(String(modalProtectedFloor))}" />
            <button class="xh-secondary" data-action="fill-suggested-floor" type="button">建议</button>
          </div>
        </div>
        <div class="xh-field">
          <label class="xh-field-label">库存数量</label>
          <input class="xh-input" data-field="modal-quantity" inputmode="numeric" placeholder="默认库存" value="${escapeHtml(String(state.settings?.defaultStockQty || ""))}" />
        </div>
        <div class="xh-field">
          <label class="xh-field-label">任务说明</label>
          <div class="xh-meta-line">确认后会先保存保护价，再创建上架任务。失败时只保留记录，不会误写价格。</div>
        </div>
        <button class="xh-primary xh-full" data-action="confirm-list-now" type="button">保存保护价并创建任务</button>
      </div>
    </div>
  `;
}

function renderPanel() {
  const panel = getPanel();
  panel.innerHTML = state.settings?.extensionToken ? buildConnectedView() : buildDisconnectedView();
}

function setHint(message, mode = "default") {
  const node = document.querySelector('[data-field="global-hint"]');
  if (!node) return;
  node.textContent = message;
  node.dataset.mode = mode;
}

async function sendMessage(payload) {
  return chrome.runtime.sendMessage(payload);
}

function parseNullableNumber(value) {
  const text = String(value ?? "").trim();
  if (!text) {
    return null;
  }
  const number = Number(text);
  return Number.isFinite(number) ? number : null;
}

async function createListNowTask(plid, title, storeId, salePriceZar, quantity) {
  return chrome.runtime.sendMessage({
    type: "xh:list-now",
    plid,
    title,
    storeId,
    salePriceZar,
    quantity,
  });
}

async function loadSession() {
  const response = await sendMessage({ type: "xh:get-session" });
  if (!response?.ok) {
    throw new Error(response?.error || "读取扩展会话失败");
  }
  return response.data;
}

async function loadPricingDraft() {
  if (!state.plid) return;
  const response = await sendMessage({
    type: "xh:get-pricing-draft",
    plid: state.plid,
    storeId: state.settings?.defaultStoreId || "",
  });
  if (response?.ok && response.data) {
    state.pricingDraft = {
      airFreightUnitCnyPerKg: response.data.airFreightUnitCnyPerKg != null ? String(response.data.airFreightUnitCnyPerKg) : "",
      purchasePriceCny: response.data.purchasePriceCny != null ? String(response.data.purchasePriceCny) : "",
      salePriceZar: response.data.salePriceZar != null ? String(response.data.salePriceZar) : "",
      actualWeightKg: response.data.actualWeightKg != null ? String(response.data.actualWeightKg) : "",
      lengthCm: response.data.lengthCm != null ? String(response.data.lengthCm) : "",
      widthCm: response.data.widthCm != null ? String(response.data.widthCm) : "",
      heightCm: response.data.heightCm != null ? String(response.data.heightCm) : "",
    };
  }
}

async function savePricingDraft() {
  if (!state.plid) return;
  await sendMessage({
    type: "xh:set-pricing-draft",
    plid: state.plid,
    storeId: state.settings?.defaultStoreId || "",
    airFreightUnitCnyPerKg: parseNullableNumber(state.pricingDraft.airFreightUnitCnyPerKg),
    purchasePriceCny: parseNullableNumber(state.pricingDraft.purchasePriceCny),
    salePriceZar: parseNullableNumber(state.pricingDraft.salePriceZar),
    actualWeightKg: parseNullableNumber(state.pricingDraft.actualWeightKg),
    lengthCm: parseNullableNumber(state.pricingDraft.lengthCm),
    widthCm: parseNullableNumber(state.pricingDraft.widthCm),
    heightCm: parseNullableNumber(state.pricingDraft.heightCm),
  });
}

async function loadSettings() {
  const response = await sendMessage({ type: "xh:get-settings" });
  if (!response?.ok) {
    throw new Error(response?.error || "读取扩展配置失败");
  }
  state.settings = response.data;
  renderPanel();
}

async function requestPreview() {
  if (!state.settings?.extensionToken || !state.settings?.defaultStoreId || !state.plid) {
    return;
  }
  setLoading(true);
  setHint("正在同步商品事实…");
  try {
    const response = await sendMessage({
      type: "xh:profit-preview",
      plid: state.plid,
      title: state.title,
      storeId: state.settings.defaultStoreId,
      airFreightUnitCnyPerKg: parseNullableNumber(state.pricingDraft.airFreightUnitCnyPerKg),
      purchasePriceCny: parseNullableNumber(state.pricingDraft.purchasePriceCny),
      salePriceZar: parseNullableNumber(state.pricingDraft.salePriceZar),
      actualWeightKg: parseNullableNumber(state.pricingDraft.actualWeightKg),
      lengthCm: parseNullableNumber(state.pricingDraft.lengthCm),
      widthCm: parseNullableNumber(state.pricingDraft.widthCm),
      heightCm: parseNullableNumber(state.pricingDraft.heightCm),
    });
    if (!response?.ok) {
      throw new Error(response?.error || "预览失败");
    }
    state.preview = response.data;
    if (
      !state.preview?.guardrail?.protected_floor_price &&
      state.preview?.pricing?.recommended_protected_floor_price_zar
    ) {
      const suggestedFloor = String(state.preview.pricing.recommended_protected_floor_price_zar);
      state.pricingDraft.suggestedProtectedFloor = suggestedFloor;
    }
    renderPanel();
    setHint("已连接 ERP，点一键上架后再选择店铺和保护价。", "success");
  } catch (error) {
    if (String(error).includes("Invalid or expired extension token")) {
      await sendMessage({ type: "xh:logout" });
      state.settings = null;
      state.preview = null;
      const panel = document.getElementById(PANEL_ID);
      if (panel) {
        panel.remove();
      }
      return;
    }
    renderPanel();
    setHint(error instanceof Error ? error.message : String(error), "error");
  } finally {
    setLoading(false);
  }
}

async function handleLogin() {
  const baseUrl = document.querySelector('[data-field="erp-base-url"]')?.value?.trim() || "";
  const username = document.querySelector('[data-field="erp-username"]')?.value?.trim() || "";
  const password = document.querySelector('[data-field="erp-password"]')?.value?.trim() || "";
  if (!baseUrl || !username || !password) {
    setHint("ERP 地址、账号、密码都要填。", "error");
    return;
  }
  setLoading(true);
  setHint("正在登录 ERP…");
  try {
    const response = await sendMessage({
      type: "xh:login",
      erpBaseUrl: baseUrl,
      username,
      password,
    });
    if (!response?.ok) {
      throw new Error(response?.error || "登录失败");
    }
    state.settings = await (await sendMessage({ type: "xh:get-settings" })).data;
    renderPanel();
    setHint("ERP 已连接。", "success");
    await requestPreview();
  } catch (error) {
    setHint(error instanceof Error ? error.message : String(error), "error");
  } finally {
    setLoading(false);
  }
}

async function handleStoreChange(storeId) {
  const response = await sendMessage({
    type: "xh:set-store",
    storeId,
  });
  if (!response?.ok) {
    setHint(response?.error || "切换店铺失败", "error");
    return;
  }
  state.settings.defaultStoreId = storeId;
  await loadPricingDraft();
  await requestPreview();
}

async function handleRecalculate() {
  await savePricingDraft();
  await requestPreview();
}

async function saveProtectedFloorValue(protectedFloorPrice, storeId) {
  if (!state.plid) {
    throw new Error("没有识别到当前商品 PLID。");
  }
  if (!storeId) {
    throw new Error("请先选择店铺。");
  }

  const response = await sendMessage({
    type: "xh:protected-floor",
    plid: state.plid,
    title: state.title,
    protectedFloorPrice,
    storeId,
  });
  if (!response?.ok) {
    throw new Error(response?.error || "保存保护价失败");
  }
  state.preview = {
    ...(state.preview || {}),
    guardrail: response.data,
    product: state.preview?.product,
  };
  return response.data;
}

async function handleSaveFloor() {
  const input = document.querySelector('[data-field="modal-protected-floor"]');
  if (!input || !state.plid) {
    return;
  }
  const rawValue = String(input.value || "").trim();
  const fallbackSuggested = state.preview?.pricing?.recommended_protected_floor_price_zar;
  const effectiveRawValue = rawValue || (fallbackSuggested != null ? String(fallbackSuggested) : "");
  if (!effectiveRawValue) {
    setHint("请先输入保护价。", "error");
    return;
  }
  if (!rawValue && fallbackSuggested != null) {
    input.value = String(fallbackSuggested);
  }
  const numericValue = Number(effectiveRawValue);
  if (!Number.isFinite(numericValue) || numericValue <= 0) {
    setHint("保护价必须大于 0。", "error");
    return;
  }
  if (!state.settings?.defaultStoreId) {
    setHint("请先选择店铺。", "error");
    return;
  }

  setLoading(true);
  setHint("正在保存保护价…");
  try {
    await saveProtectedFloorValue(numericValue, state.settings.defaultStoreId);
    renderPanel();
    setHint("保护价已保存，后续 listing 同步后会自动挂到 AutoBid。", "success");
  } catch (error) {
    setHint(error instanceof Error ? error.message : String(error), "error");
  } finally {
    setLoading(false);
  }
}

async function handleApplySuggestedFloor() {
  const suggested = state.preview?.pricing?.recommended_protected_floor_price_zar;
  if (suggested == null) {
    setHint("请先完成试算后再采用建议保护价。", "error");
    return;
  }
  const input = document.querySelector('[data-field="modal-protected-floor"]');
  if (input) {
    input.value = String(suggested);
  }
}

async function handleLogout() {
  await sendMessage({ type: "xh:logout" });
  state.settings = await (await sendMessage({ type: "xh:get-settings" })).data;
  state.preview = null;
  renderPanel();
  setHint("已退出扩展连接。");
}

function setModalOpen(open) {
  const modal = document.querySelector('[data-modal="list-now"]');
  if (!modal) return;
  modal.classList.toggle("hidden", !open);
}

async function handleListNow() {
  const select = document.querySelector('[data-field="modal-store-select"]');
  const storeId = select?.value || state.settings?.defaultStoreId;
  if (!storeId) {
    setHint("请先选择店铺。", "error");
    return;
  }

  const protectedFloorInput = document.querySelector('[data-field="modal-protected-floor"]');
  const suggestedProtectedFloor = state.preview?.pricing?.recommended_protected_floor_price_zar;
  const protectedFloorRaw =
    String(protectedFloorInput?.value || "").trim() ||
    (suggestedProtectedFloor != null ? String(suggestedProtectedFloor) : "");
  const protectedFloorPrice = Number(protectedFloorRaw);
  if (!Number.isFinite(protectedFloorPrice) || protectedFloorPrice <= 0) {
    setHint("请先填写有效保护价。", "error");
    return;
  }

  const salePriceZar =
    parseNullableNumber(state.pricingDraft.salePriceZar) ??
    state.preview?.pricing?.sale_price_zar ??
    null;
  const quantityInput = document.querySelector('[data-field="modal-quantity"]');
  const quantity = parseNullableNumber(quantityInput?.value) ?? parseNullableNumber(state.settings?.defaultStockQty) ?? 1;
  if (salePriceZar == null) {
    setHint("请先确认销售价后再发起一键上架。", "error");
    return;
  }

  setLoading(true);
  setHint("正在保存保护价并提交上架…");
  try {
    await saveProtectedFloorValue(protectedFloorPrice, storeId);
    const response = await createListNowTask(state.plid, state.title, storeId, salePriceZar, quantity);
    if (!response?.ok) {
      throw new Error(response?.error || "创建任务失败");
    }
    setModalOpen(false);
    const automation = response.data?.automation;
    const openedListingCenter = Boolean(automation?.openedListingCenter);
    if (automation?.outcome === "buyable") {
      setHint(
        openedListingCenter ? "已上架，已为你打开上架记录" : "已上架",
        "success",
      );
      return;
    }
    if (automation?.outcome === "failed") {
      setHint(
        openedListingCenter ? "上架失败，已为你打开上架记录" : "上架失败",
        "error",
      );
      return;
    }
    if (automation?.message) {
      setHint("正在处理，结果出来后会显示到上架记录", "success");
      return;
    }
    setHint("正在处理，结果出来后会显示到上架记录", "success");
  } catch (error) {
    setHint(error instanceof Error ? error.message : String(error), "error");
  } finally {
    setLoading(false);
  }
}

function bindEvents() {
  document.addEventListener("click", (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) {
      return;
    }

    if (target.matches('[data-action="refresh"]')) {
      void requestPreview();
    }
    if (target.matches('[data-action="login"]')) {
      void handleLogin();
    }
    if (target.matches('[data-action="fill-suggested-floor"]')) {
      void handleApplySuggestedFloor();
    }
    if (target.matches('[data-action="recalculate"]')) {
      void handleRecalculate();
    }
    if (target.matches('[data-action="logout"]')) {
      void handleLogout();
    }
    if (target.matches('[data-action="open-list-now"]')) {
      setModalOpen(true);
    }
    if (target.matches('[data-action="close-list-now"]')) {
      setModalOpen(false);
    }
    if (target.matches('[data-action="confirm-list-now"]')) {
      void handleListNow();
    }
  });

  document.addEventListener("change", (event) => {
    const target = event.target;
    if (target instanceof HTMLSelectElement) {
      if (target.matches('[data-field="modal-store-select"]')) {
        return;
      }
      return;
    }
    if (target instanceof HTMLInputElement) {
      if (target.matches('[data-field="air-freight-unit"]')) {
        state.pricingDraft.airFreightUnitCnyPerKg = target.value;
      }
      if (target.matches('[data-field="purchase-price"]')) {
        state.pricingDraft.purchasePriceCny = target.value;
      }
      if (target.matches('[data-field="sale-price"]')) {
        state.pricingDraft.salePriceZar = target.value;
      }
      if (target.matches('[data-field="actual-weight"]')) {
        state.pricingDraft.actualWeightKg = target.value;
      }
      if (target.matches('[data-field="length-cm"]')) {
        state.pricingDraft.lengthCm = target.value;
      }
      if (target.matches('[data-field="width-cm"]')) {
        state.pricingDraft.widthCm = target.value;
      }
      if (target.matches('[data-field="height-cm"]')) {
        state.pricingDraft.heightCm = target.value;
      }
    }
  });
}

function installNavigationWatcher() {
  let lastUrl = window.location.href;
  const rerenderIfChanged = () => {
    if (window.location.href === lastUrl) {
      return;
    }
    lastUrl = window.location.href;
    state.plid = extractPlid();
    state.title = getProductTitle();
    setTimeout(() => {
      void requestPreview();
    }, 300);
  };

  const originalPushState = history.pushState;
  history.pushState = function (...args) {
    const result = originalPushState.apply(this, args);
    rerenderIfChanged();
    return result;
  };
  window.addEventListener("popstate", rerenderIfChanged);

  const observer = new MutationObserver(() => rerenderIfChanged());
  observer.observe(document.documentElement, { childList: true, subtree: true });
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "xh:session-updated") {
    void boot(true);
    sendResponse({ ok: true });
  }
});

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function formatNumber(value, digits = 2) {
  if (value == null || value === "" || !Number.isFinite(Number(value))) {
    return "待测算";
  }
  return Number(value).toLocaleString("en-ZA", {
    maximumFractionDigits: digits,
    minimumFractionDigits: digits,
  });
}

function formatZar(value) {
  if (value == null || value === "" || !Number.isFinite(Number(value))) {
    return "待测算";
  }
  return `R ${formatNumber(value, 2)}`;
}

async function boot(forceRefresh = false) {
  state.plid = extractPlid();
  state.title = getProductTitle();
  if (!state.plid) {
    return;
  }
  const session = await loadSession();
  if (!session?.connected) {
    const panel = document.getElementById(PANEL_ID);
    if (panel) {
      panel.remove();
    }
    state.settings = null;
    state.preview = null;
    return;
  }
  await loadSettings();
  if (state.settings?.extensionToken) {
    if (forceRefresh) {
      state.preview = null;
    }
    await loadPricingDraft();
    renderPanel();
    if (state.settings?.defaultStoreId) {
      await requestPreview();
    } else {
      setHint("请选择一个默认店铺后再加载商品护栏。");
    }
  }
}

bindEvents();
installNavigationWatcher();
void boot();
