function setStatus(message, mode = "default") {
  const status = document.getElementById("status");
  status.textContent = message;
  status.dataset.mode = mode;
}

async function sendMessage(message) {
  return chrome.runtime.sendMessage(message);
}

function renderLoginView(settings) {
  document.getElementById("title").textContent = "扩展连接";
  document.getElementById("loginView").classList.remove("hidden");
  document.getElementById("connectedView").classList.add("hidden");
  document.getElementById("erpBaseUrl").value = settings?.erpBaseUrl || "";
}

function renderConnectedView(session) {
  document.getElementById("title").textContent = "已连接";
  document.getElementById("loginView").classList.add("hidden");
  document.getElementById("connectedView").classList.remove("hidden");

  const userMeta = document.getElementById("userMeta");
  userMeta.textContent = `${session.user?.username || "已登录"} · ${session.stores.length} 个店铺`;

  const select = document.getElementById("storeSelect");
  select.innerHTML = "";
  for (const store of session.stores) {
    const option = document.createElement("option");
    option.value = store.store_id;
    option.textContent = store.name;
    if (store.store_id === session.defaultStoreId) {
      option.selected = true;
    }
    select.appendChild(option);
  }
  document.getElementById("defaultStockQty").value = session.defaultStockQty || "";
}

async function loadSession() {
  const response = await sendMessage({ type: "xh:get-session" });
  if (!response?.ok) {
    throw new Error(response?.error || "读取会话失败");
  }
  return response.data;
}

async function loadPopup() {
  const session = await loadSession();
  if (session?.connected) {
    renderConnectedView(session);
    setStatus("扩展已连接。", "success");
    return;
  }

  const settingsResponse = await sendMessage({ type: "xh:get-settings" });
  if (!settingsResponse?.ok) {
    throw new Error(settingsResponse?.error || "读取配置失败");
  }
  renderLoginView(settingsResponse.data);
  setStatus("未登录时不会向页面注入任何 ERP UI。");
}

async function login() {
  const erpBaseUrl = document.getElementById("erpBaseUrl").value.trim();
  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value.trim();
  if (!erpBaseUrl || !username || !password) {
    setStatus("ERP 地址、账号、密码都不能为空。", "error");
    return;
  }

  setStatus("正在登录 ERP…");
  const response = await sendMessage({
    type: "xh:login",
    erpBaseUrl,
    username,
    password,
  });
  if (!response?.ok) {
    throw new Error(response?.error || "登录失败");
  }
  const session = await loadSession();
  renderConnectedView(session);
  setStatus("登录成功，已开启页面注入。", "success");
}

async function refreshSession() {
  const session = await loadSession();
  if (session?.connected) {
    renderConnectedView(session);
    setStatus("连接状态已刷新。", "success");
    return;
  }
  renderLoginView({});
  setStatus("登录已失效，请重新登录。", "error");
}

async function logout() {
  await sendMessage({ type: "xh:logout" });
  renderLoginView({});
  setStatus("已退出，页面将不再注入。", "success");
}

async function updateStoreSelection() {
  const storeId = document.getElementById("storeSelect").value;
  const response = await sendMessage({
    type: "xh:set-store",
    storeId,
  });
  if (!response?.ok) {
    throw new Error(response?.error || "切换店铺失败");
  }
  setStatus("默认店铺已更新。", "success");
}

async function updateDefaultStock() {
  const defaultStockQty = document.getElementById("defaultStockQty").value.trim();
  const response = await sendMessage({
    type: "xh:set-default-stock",
    defaultStockQty,
  });
  if (!response?.ok) {
    throw new Error(response?.error || "更新默认库存失败");
  }
  setStatus("默认库存已更新。", "success");
}

document.getElementById("loginButton").addEventListener("click", () => {
  login().catch((error) => {
    setStatus(error instanceof Error ? error.message : String(error), "error");
  });
});

document.getElementById("refreshButton").addEventListener("click", () => {
  refreshSession().catch((error) => {
    setStatus(error instanceof Error ? error.message : String(error), "error");
  });
});

document.getElementById("logoutButton").addEventListener("click", () => {
  logout().catch((error) => {
    setStatus(error instanceof Error ? error.message : String(error), "error");
  });
});

document.getElementById("storeSelect").addEventListener("change", () => {
  updateStoreSelection().catch((error) => {
    setStatus(error instanceof Error ? error.message : String(error), "error");
  });
});

document.getElementById("defaultStockQty").addEventListener("change", () => {
  updateDefaultStock().catch((error) => {
    setStatus(error instanceof Error ? error.message : String(error), "error");
  });
});

loadPopup().catch((error) => {
  setStatus(error instanceof Error ? error.message : String(error), "error");
});
